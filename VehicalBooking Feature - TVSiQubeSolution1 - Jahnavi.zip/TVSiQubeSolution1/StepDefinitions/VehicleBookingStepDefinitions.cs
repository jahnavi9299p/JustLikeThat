using System;
using TechTalk.SpecFlow.Assist;
using TVSiQube;

namespace TVSiQubeSolution1.StepDefinitions
{
    [Binding]
    public class VehicleBookingStepDefinitions
    {
        private readonly ScenarioContext ScenerioContextObj;
        private BookingDetails BookingDetailsObj = new BookingDetails();
        private string? Result;
        public VehicleBookingStepDefinitions(ScenarioContext input)
        {
            ScenerioContextObj = input;
        }

        [Given(@"the following CustomerData for CustomerRegistration:")]
        public void GivenTheFollowingCustomerDataForCustomerRegistration(Table table)
        {
            BookingDetailsObj = table.CreateInstance<BookingDetails>();
            //throw new PendingStepException();
        }

        [When(@"Valid Customer Registration Request is received")]
        public void WhenValidCustomerRegistrationRequestIsReceived()
        {
            if (BookingDetailsObj.CustomerId == 0)
            {
                throw new PendingStepException();
            }
            else
            {
                Result = "Registration E-Mail sent";
            }
        }

        [Then(@"result for CustomerRegistration should be ""([^""]*)""")]
        public void ThenResultForCustomerRegistrationShouldBe(string ExpectedResult)
        {
            Result.Should().Be(ExpectedResult); 
            //throw new PendingStepException();
        }

        [Given(@"the following CustomerData:")]
        public void GivenTheFollowingCustomerData(Table table)
        {
            BookingDetailsObj = table.CreateInstance<BookingDetails>();
            //throw new PendingStepException();
        }

        [Given(@"the following CustomerData for PaymentConfirmation:")]
        public void GivenTheFollowingCustomerDataForPaymentConfirmation(Table table)
        {
            BookingDetailsObj = table.CreateInstance<BookingDetails>();
            //throw new PendingStepException();
        }

        [When(@"Valid customer Payment Notification Received")]
        public void WhenValidCustomerPaymentNotificationReceived()
        {
            if (BookingDetailsObj.Status != 1)
            {
                throw new PendingStepException();
            }
            else
            {
                Result = "Payment Status E-Mail sent";
            }
            //throw new PendingStepException();
        }

        [Then(@"result for PaymentConfirmation should be ""([^""]*)""")]
        public void ThenResultForPaymentConfirmationShouldBe(string ExpectedResult)
        {
            Result.Should().Be(ExpectedResult);
            //throw new PendingStepException();
        }

        [When(@"Invalid customer Payment Notification is Received")]
        public void WhenInvalidCustomerPaymentNotificationIsReceived()
        {
            if (BookingDetailsObj.Status != 1)
            {
                Result = "Payment Status E-Mail sent";
            }
            else
            {
                throw new PendingStepException();
            }
        }

        [Given(@"the following CustomerData for DealerSelection:")]
        public void GivenTheFollowingCustomerDataForDealerSelection(Table table)
        {
            BookingDetailsObj = table.CreateInstance<BookingDetails>();
            //throw new PendingStepException();
        }

        [When(@"Customer Selects Dealer")]
        public void WhenCustomerSelectsDealer()
        {
            Result = "Dealer Confirmation";
            //throw new PendingStepException();
        }

        [Then(@"result for DealerSelection should be ""([^""]*)""")]
        public void ThenResultForDealerSelectionShouldBe(string ExpectedResult)
        {
            Result.Should().Be(ExpectedResult); 
            //throw new PendingStepException();
        }

        [Then(@"data must be persisted")]
        public void ThenDataMustBePersisted()
        {
            //throw new PendingStepException();
        }

        [Given(@"only one dealer is available in the city")]
        public void GivenOnlyOneDealerIsAvailableInTheCity()
        {
            //throw new PendingStepException();
        }

        [When(@"customer has not chosen dealer")]
        public void WhenCustomerHasNotChosenDealer()
        {
            //throw new PendingStepException();
        }

        [Then(@"dealer must be auto allocated")]
        public void ThenDealerMustBeAutoAllocated()
        {
            Result = "Dealer Confirmation";
            //throw new PendingStepException();
        }

        //[Then(@"dealer confirmation mail sent to customer")]
        //public void ThenDealerConfirmationMailSentToCustomer()
        //{
        //    //throw new PendingStepException();
        //}

        //[Given(@"Customer data an dealer id \(DMS_Request is null\)")]
        //public void GivenCustomerDataAnDealerIdDMS_RequestIsNull()
        //{
        //    throw new PendingStepException();
        //}

        //[When(@"DMS is null and dealer id is >(.*)")]
        //public void WhenDMSIsFalseAndDealerIdIs(int p0)
        //{
        //    throw new PendingStepException();
        //}

        [Given(@"the following CustomerData for DealerAllocation:")]
        public void GivenTheFollowingCustomerDataForDealerAllocation(Table table)
        {
            BookingDetailsObj = table.CreateInstance<BookingDetails>();
            //throw new PendingStepException();
        }

        [When(@"DMS is false and dealer id is greater than (.*)")]
        public void WhenDMSIsFalseAndDealerIdIsGreaterThanZero(int p0)
        {
            if(BookingDetailsObj.DMS_Request != "false" || BookingDetailsObj.DealerId <= 0)
            {
                throw new PendingStepException();
            }
            else
            {
                p0 = 1;
            }
        }

        [Then(@"dealer allocation information is sent to DMS")]
        public void ThenDealerAllocationInformationIsSentToDMS()
        {
            //throw new PendingStepException();
        }

        [Then(@"update DMS_Request as ""([^""]*)""")]
        public void ThenUpdateDMS_RequestAs(string @true)
        {
            BookingDetailsObj.DMS_Request = "true";
            Result = "Dealer Allocation is Success";
            //throw new PendingStepException();
        }

        [Then(@"result for DealerAllocation should be ""([^""]*)""")]
        public void ThenResultForDealerAllocationShouldBe(string ExpectedResult)
        {
            Result.Should().Be(ExpectedResult);
        }

    }
}
